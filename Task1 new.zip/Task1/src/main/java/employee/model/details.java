package employee.model;
import employee.dao.detailsDAO;
import employee.dao.employeeDAO;
import employee.model.employee;


public class details {
    
	
  public int employeeId;
  public String fathername;
  public String mname;
  public String status;
  public String address;
  
  public String degree;
  public String collegename;
  public int year;
  public String percent ;

  public String companyname;
  public String designation;
  public int salary;
  public int experience;

public String getDegree() {
	return degree;
}

public void setDegree(String degree) {
	this.degree = degree;
}

public int getYear() {
	return year;
}

public void setYear(int year) {
	this.year = year;
}

public String getPercent() {
	return percent;
}

public void setPercent(String percent) {
	this.percent = percent;
}

public String getCompanyname() {
	return companyname;
}

public void setCompanyname(String companyname) {
	this.companyname = companyname;
}

public int getSalary() {
	return salary;
}

public void setSalary(int salary) {
	this.salary = salary;
}

public int getExperience() {
	return experience;
}

public void setExperience(int experience) {
	this.experience = experience;
}

public int getEmployeeId() {
	return employeeId;
}

public void setEmployeeId(int employeeId) {
	this.employeeId = employeeId;
}


public details(int employeeId, String fathername, String mname, String status, String address, String degree,
		String collegename, int year, String percent, String companyname, String designation, int salary,
		int experience) {
	super();
	this.employeeId = employeeId;
	this.fathername = fathername;
	this.mname = mname;
	this.status = status;
	this.address = address;
	this.degree = degree;
	this.collegename = collegename;
	this.year = year;
	this.percent = percent;
	this.companyname = companyname;
	this.designation = designation;
	this.salary = salary;
	this.experience = experience;
}

public details(String fathername, String mname, String status, String address, String degree, String collegename,
		int year, String percent, String companyname, String designation, int salary, int experience) {
	super();
	this.fathername = fathername;
	this.mname = mname;
	this.status = status;
	this.address = address;
	this.degree = degree;
	this.collegename = collegename;
	this.year = year;
	this.percent = percent;
	this.companyname = companyname;
	this.designation = designation;
	this.salary = salary;
	this.experience = experience;
}

public details(int employeeId, String fathername, String mname, String status, String address, String collegename,
		String designation) {
	super();
	this.employeeId = employeeId;
	this.fathername = fathername;
	this.mname = mname;
	this.status = status;
	this.address = address;
	this.collegename = collegename;
	this.designation = designation;
}

public details(String fathername, String mname, String status, String address, String collegename, String designation) {
	super();
	this.fathername = fathername;
	this.mname = mname;
	this.status = status;
	this.address = address;
	this.collegename = collegename;
	this.designation = designation;
	}

public String getMname() {
	return mname;
}

public void setMname(String mname) {
	this.mname = mname;
}

public String getStatus() {
	return status;
}

public void setStatus(String status) {
	this.status = status;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public String getFathername() {
	return fathername;
}
public void setFathername(String fathername) {
	this.fathername = fathername;
}
public String getCollegename() {
	return collegename;
}
public void setCollegename(String collegename) {
	this.collegename = collegename;
}
public String getDesignation() {
	return designation;
}
public void setDesignation(String designation) {
	this.designation = designation;
}
 
}
