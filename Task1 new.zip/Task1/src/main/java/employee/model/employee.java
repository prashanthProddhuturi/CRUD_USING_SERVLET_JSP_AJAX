package employee.model;

import java.util.Arrays;

public class employee {
	public employee() {
	
	}
	public int otp;
	String[] checkid;
	String searches;
	
	public String getsearches() {
		return searches;
	}
	public void setsearches(String searches) {
		this.searches = searches;
	}
	public String[] getCheckid() {
		return checkid;
	}
	public void setCheckid(String[] checkid) {
		this.checkid = checkid;
	}
	public int getOtp() {
		return otp;
	}
	public void setOtp(int otp) {
		this.otp = otp;
	}
	public int id;
	public String name;
	public String mail;
	public String phone;
	public String password;
	
	@Override
	public String toString() {
		return "employee [checkid=" + Arrays.toString(checkid) + ", id=" + id + ", name=" + name + ", mail=" + mail
				+ ", phone=" + phone + ", password=" + password + "]";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public employee(int id, String name, String mail, String phone, String password) {
		super();
		this.id = id;
		this.name = name;
		this.mail = mail;
		this.phone = phone;
		this.password = password;
	}
	public employee(String name, String mail, String phone, String password) {
		super();
		this.name = name;
		this.mail = mail;
		this.phone = phone;
		this.password = password;
	}
	public employee(int otp, int id, String name, String mail, String phone, String password) {
		super();
		this.otp = otp;
		this.id = id;
		this.name = name;
		this.mail = mail;
		this.phone = phone;
		this.password = password;
	}
	public employee(int otp, String mail) {
		super();
		this.otp = otp;
		this.mail = mail;
	}
	public employee(int id, String name, String mail, String phone) {
		super();
		this.id = id;
		this.name = name;
		this.mail = mail;
		this.phone = phone;
	}
	
		
	

}
