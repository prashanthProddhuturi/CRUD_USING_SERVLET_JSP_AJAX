package employee.dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
//import java.util.Arrays;
import java.util.List;

import employee.model.employee;

public class employeeDAO {
	String jdbcURL = "jdbc:mysql://localhost:3306/codetru?useSSL=false";
	String jdbcUsername = "root";
    String jdbcpassword = "";

	
	
	private static final String INSERT_USERS_SQL = "INSERT INTO employees" + " (name,mail,phone,password) VALUES "+ " (?,?,?,?);";
	private static final String SELECT_USER_BY_ID = "select id,name,mail,phone,password from employees where id=?";
	//private static final String SELECT_ALL_USERS = "select * from employees";
	private static final String DELETE_USERS_SQL = "delete from employees where id = ?;";
	private static final String UPDATE_USERS_SQL = "update employees set name = ?,mail= ?, phone =?,password=? where id = ?;";
	private static final String VALIDATE_USER="select * from employees where mail=? and password=?;";
	private static final String UPDATE_OTP="update employees set otp=? where mail=?;";
	private static final String VALIDATE_OTP="select otp from employees where mail=?;";
    		
    private int noOfRecords;
	public employeeDAO() {
	}

	protected Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcpassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}
	public boolean deleteSelected(String[] checkid) throws SQLException {
		boolean deleted=false;
			
			List<Integer> list=new ArrayList<Integer>();
			for(int l=0;l<checkid.length;l++)
			{
			   list.add(Integer.parseInt(checkid[l]));	
			}
			System.out.println("list has:"+list);
			Object[] values=list.toArray();
			String arrayIds = "";
			for(int i=0 ;i<values.length;i++){  
				arrayIds += values[i];
				if(i < (values.length - 1) ) {
					arrayIds += ",";
				}}
			System.out.println("values are:"+ arrayIds.toString());
			try (Connection connection = getConnection();)
			{
				PreparedStatement statement = connection.prepareStatement("DELETE FROM employees where id in ("+arrayIds+")");
				deleted= statement.executeUpdate() > 0;
				System.out.println("executed delete multiple option");
		}
		return deleted;
	}
	
	public boolean updateOtp(String userMail) throws SQLException {
		boolean rowUpdated;
		System.out.println("updateOtp");

		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(UPDATE_OTP);) {
			statement.setInt(1, (int)(Math.random()*10000));
			statement.setString(2,userMail);
			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}

	public int validateOtp(String mail) throws SQLException {
		int otp=0;
		System.out.println("VALIDATE_OTP");
		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(VALIDATE_OTP)) {
			preparedStatement.setString(1,mail);
			System.out.println("mail is:"+mail);

					ResultSet rs= preparedStatement.executeQuery();
					rs.next();
					otp = rs.getInt("otp");
					System.out.println("db_otp:"+otp);
					System.out.println("result set:"+rs);
					  
		}return otp;
	}

	public void insertUser(employee user) throws SQLException {
		System.out.println(INSERT_USERS_SQL);
		
		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {
			preparedStatement.setString(1, user.getName());
			preparedStatement.setString(2, user.getMail());
			preparedStatement.setString(3, user.getPhone());
			preparedStatement.setString(4, user.getPassword());
			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			printSQLException(e);
		}
	}
	
	public employee selectUser(int id) {
		employee user = null;
	
		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(SELECT_USER_BY_ID);) {
			preparedStatement.setInt(1,id);
			System.out.println(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				String name = rs.getString("name");
				String mail = rs.getString("mail");
				String phone = rs.getString("phone");
				String password=rs.getString("password");
				user = new employee(id,name,mail,phone,password);
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return user;
	}
	public List<employee> searchbysearchId(String searchId) throws SQLException {
		//String query="Select * from employees where phone= '"+searchId+"' OR mail= '"+searchId+"' OR name='"+searchId+"'";
		String query="Select * from employees where phone like ? OR mail like ? OR name like ?";
		System.out.println("SEARCH BY SearchID");
		
		List<employee> users=new ArrayList<>();
		try(Connection connection =getConnection();
				PreparedStatement statement=connection.prepareStatement(query);) {
			System.out.println(query);
			statement.setString(1, "%"+searchId+"%");
			statement.setString(2, "%"+searchId+"%");
			statement.setString(3, "%"+searchId+"%");
			ResultSet rs=statement.executeQuery();
			while(rs.next()) {
				Integer id=rs.getInt("id");
				String name=rs.getString("name");
				String mail=rs.getString("mail");
				String phone=rs.getString("phone");
				String password=rs.getString("password");
				
			users.add(new employee(id,name,mail,phone,password));
			}
		}
		return users;
	}
	
	public List<employee> selectAllUsers(int offset, int noOfRecords)
    {
        String query = "select SQL_CALC_FOUND_ROWS * from employees limit " + offset + ", " + noOfRecords;
		List<employee> users = new ArrayList<>();
		try (Connection connection = getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(query);) {
			System.out.println(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				Integer id = rs.getInt("id");
				String name = rs.getString("name");
				String mail = rs.getString("mail");
				String phone = rs.getString("phone");
				String password=rs.getString("password");
				users.add(new employee(id,name,mail,phone,password));
			}
			rs = preparedStatement.executeQuery("SELECT FOUND_ROWS()");
			  
            if (rs.next())
               this.noOfRecords = rs.getInt(1);
            
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}
	public int getNoOfRecords() {
		return noOfRecords;
	}

	public boolean deleteUser(int id) throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(DELETE_USERS_SQL);) {
			statement.setInt(1, id);
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	public boolean updateUser(employee user) throws SQLException {
		boolean rowUpdated;
		try (Connection connection = getConnection();
			PreparedStatement statement = connection.prepareStatement(UPDATE_USERS_SQL);) {
			
			statement.setString(1, user.getName());
			statement.setString(2, user.getMail());
			statement.setString(3, user.getPhone());
			statement.setString(4, user.getPassword());
			statement.setInt(5,user.getId());
			System.out.println("******Id******");
			System.out.println(user.id);
			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}
	
	public boolean loginUser(String mail,String password) throws SQLException {
		boolean loginchecked=false;
		int count=0;

		try(Connection connection=getConnection();
				PreparedStatement statement=connection.prepareStatement(VALIDATE_USER);) {
			statement.setString(1,mail);
			statement.setString(2,password);
			ResultSet rs=statement.executeQuery();
			if(rs.next()) {
				count=1;
				System.out.println(count);
			    if(count>0)
				loginchecked=true;
			}
			 else
				loginchecked=false;
		}
		return loginchecked;
	}
	private void printSQLException(SQLException ex) {
		for (Throwable e : ex) {
			if (e instanceof SQLException) {
				e.printStackTrace(System.err);
				System.err.println("SQLState: " + ((SQLException) e).getSQLState());
				System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
				System.err.println("Message: " + e.getMessage());
				Throwable t = ex.getCause();
				while (t != null) {
					System.out.println("Cause: " + t);
					t = t.getCause();
				}
			}
		}
	}
}