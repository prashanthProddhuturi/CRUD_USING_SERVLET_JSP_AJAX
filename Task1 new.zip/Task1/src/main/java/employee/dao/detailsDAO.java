package employee.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import employee.model.details;
import employee.model.employee;

public class detailsDAO {
	private String jdbcURL = "jdbc:mysql://localhost:3306/codetru?useSSL=false";
	private String jdbcUsername = "root";
	private String jdbcpassword = "";

	public detailsDAO() {
		
			}
	
	protected Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcpassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}
	public List<employee> viewDetails(int id) throws SQLException {
		List<employee> users=new ArrayList<>();

		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement("select * from employees where id=?");) {
			statement.setInt(1, id);
			ResultSet rs = statement.executeQuery();
			while(rs.next()) {
				String name = rs.getString("name");
				String mail = rs.getString("mail");
				String phone = rs.getString("phone");
				users.add(new employee(id,name,mail,phone));
			}
		}
			return users;
		}
	public List<details> SelectDetails(int EmployeeId) throws SQLException {
		List<details> users=new ArrayList<>();
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement("select * from details where EmployeeId=?");) {
			statement.setInt(1, EmployeeId);
			ResultSet rs = statement.executeQuery();
			while(rs.next()) {
				String fathername = rs.getString("fathername");
				String mname=rs.getString("mname");
				String status =rs.getString("status");
				String address=rs.getString("address");
				String degree=rs.getString("degree");
				String collegename = rs.getString("collegename");
				int year=rs.getInt("year");
				String percent=rs.getString("percent");
				String companyname=rs.getString("companyname");
				String designation = rs.getString("designation");
				int salary=rs.getInt("salary");
				int experience=rs.getInt("experience");

				users.add(new details(fathername,mname,status,address,degree,collegename,year,percent,companyname,designation,salary,experience));
			}
		}
			return users;
		}

		public void  employeeDetails(details user) throws SQLException {
		System.out.println("Employee Details");
		String query1="insert into details" + "(fathername,mname,status,address,degree,collegename,year,percent,companyname,designation,salary,experience)"+"values (?,?,?,?,?,?,?,?,?,?,?,?);";
		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(query1)) {
			System.out.println("id is :"+user.employeeId);

			preparedStatement.setString(1, user.getFathername());
			preparedStatement.setString(2, user.getMname());
			System.out.println(user.getMname());
			preparedStatement.setString(3, user.getStatus());
			preparedStatement.setString(4, user.getAddress());
			preparedStatement.setString(5, user.getDegree());
			preparedStatement.setString(6, user.getCollegename());
			preparedStatement.setInt(7, user.getYear());
			preparedStatement.setString(8, user.getPercent());
			preparedStatement.setString(9, user.getCompanyname());
			preparedStatement.setString(10, user.getDesignation());
			preparedStatement.setInt(11, user.getSalary());
			preparedStatement.setInt(12, user.getExperience());
			
			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} 		}
	public boolean editdetails(details user) throws SQLException {
		boolean detailsedited;
		String query="update details set fathername=?,mname=?,status=?,address=?,degree=?,collegename=?,year=?,percent=?,companyname=?,designation=?,salary=?,experience=? where employeeId=?";
		try (Connection connection=getConnection();
				PreparedStatement preparedStatement=connection.prepareStatement(query)) {
			preparedStatement.setString(1, user.getFathername());
			preparedStatement.setString(2, user.getMname());
			System.out.println(user.getMname());
			preparedStatement.setString(3, user.getStatus());
			preparedStatement.setString(4, user.getAddress());
			preparedStatement.setString(5, user.getDegree());
			preparedStatement.setString(6, user.getCollegename());
			preparedStatement.setInt(7, user.getYear());
			preparedStatement.setString(8, user.getPercent());
			preparedStatement.setString(9, user.getCompanyname());
			preparedStatement.setString(10, user.getDesignation());
			preparedStatement.setInt(11, user.getSalary());
			preparedStatement.setInt(12, user.getExperience());
			preparedStatement.setInt(13, user.getEmployeeId());
			detailsedited=preparedStatement.executeUpdate()>0;
		}
		return detailsedited;
	}
	public details selectEmployee(int employeeId) throws SQLException {
		details user = null;
		String query="select employeeId,fathername,mname,status,address,degree,collegename,year,percent,companyname,"
				+ "designation,salary,experience from details where employeeId=?";
		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(query);) {
			preparedStatement.setInt(1,employeeId);
			System.out.println("employeeId to edit is:"+employeeId);
			System.out.println(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				String fathername = rs.getString("fathername");
				String mname = rs.getString("mname");
				String status = rs.getString("status");
				String address = rs.getString("address");
				String degree = rs.getString("degree");
				String collegename = rs.getString("collegename");
				int year=rs.getInt("year");
				String percent =rs.getString("percent");
				String companyname = rs.getString("companyname");
				String designation = rs.getString("designation");
				int salary=rs.getInt("salary");
				int experience=rs.getInt("experience");
		user=new details(fathername,mname,status,address,degree,collegename,year,percent,companyname,designation,salary,experience);
     	}
	}
		return user;
	}

	public boolean deletedetails(int employeeId) throws SQLException {
		// TODO Auto-generated method stub
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement("delete from details where employeeId=?");) {
			statement.setInt(1, employeeId);
			rowDeleted = statement.executeUpdate() > 0;
			System.out.println("deleted details successfully");
		}
		return rowDeleted;
	}
	public boolean deleteSelectedDetails(String[] checkid) throws SQLException {
		boolean deleted=false;
		try (Connection connection = getConnection();)
		{
			List<Integer> list=new ArrayList<Integer>();
			for(int l=0;l<checkid.length;l++)
			{
			     list.add(Integer.parseInt(checkid[l]));	
			}
			System.out.println("list has:"+list);
			Object[] values=list.toArray();
			String arrayIds = "";
			for(int i=0 ;i<values.length;i++){  
				arrayIds += values[i];
				if(i < (values.length - 1) ) {
					arrayIds += ",";
				}}
			System.out.println("values are:"+ arrayIds.toString());
			PreparedStatement statement = connection.prepareStatement("DELETE FROM details where employeeId in ("+arrayIds+")");
			deleted= statement.executeUpdate() > 0;
			System.out.println("executed delete multiple details option");
		}
		return deleted;
	}
}
