package servlet;

	import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
	import javax.servlet.RequestDispatcher;
	import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONException;
import org.json.JSONObject;

import employee.dao.detailsDAO;
import employee.dao.employeeDAO;
import employee.model.details;
import employee.model.employee;

	@WebServlet("/")
	public class RegisterServlet extends HttpServlet {
		private static final long serialVersionUID = 1L;
		private employeeDAO userDAO;
		private detailsDAO viewDAO;
		Cookie ck;
		public void init() {
			userDAO = new employeeDAO();
			viewDAO=new detailsDAO();
		}
		
		protected void doPost(HttpServletRequest request, HttpServletResponse response)
				throws ServletException, IOException {
			doGet(request, response);
		}
		protected void doGet(HttpServletRequest request, HttpServletResponse response)
				throws ServletException, IOException {
			String action = request.getServletPath();

			try {
				switch (action) {
				case "/new":
					showNewForm(request, response);
					break;
				case "/insert":
					insertUser(request, response);
					break;
				case "/delete":
					deleteUser(request, response);
					break;
				case "/edit":
					showEditForm(request, response);
					break;
				case "/editdetails":
					editdetailsform(request,response);
					break;
				case "/update":
					updateUser(request, response);
					break;
				case "/updatedetails":
					updatedetails(request,response);
					break;
				case "/login":
					loginUser(request,response);
					break;
				case "/validate":
					validateOtp(request,response);
					break;
				case "/list":
					listUser(request,response);
					break;	
				case "/logout":
					logoutUser(request,response);
					break;
				case"/deleteSelected":
					deleteSelected(request,response);
					break;
				case"/search":
					search(request,response);
					break;
				case"/view":
					viewDetails(request,response);
					break;
				case"/adddetails":
					addDetails(request,response);
					break;		
				}
			} catch (SQLException ex) {
				throw new ServletException(ex);
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}
		public void addDetails(HttpServletRequest request,HttpServletResponse response) throws SQLException, IOException, ServletException {
			HttpSession session=request.getSession(false);
			if(session.getAttribute("x")==null) {
				RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
				dispatcher.forward(request, response);
			}
			else {
			System.out.println("adding employee details");
			 String fathername=request.getParameter("fathername");
			 String mname=request.getParameter("mname"); 
			 String status=request.getParameter("status"); 
			 String address=request.getParameter("address");
			 String degree=request.getParameter("degree");
			 String collegename=request.getParameter("collegename");
			 int year=Integer.parseInt(request.getParameter("year"));
			 String percent=request.getParameter("percent");
			 String companyname=request.getParameter("companyname");
			 String designation=request.getParameter("designation"); 
			 int salary=Integer.parseInt(request.getParameter("salary"));
			 int experience=Integer.parseInt(request.getParameter("experience"));
			 details newdel=new details(fathername,mname,status,address,degree,collegename,year,percent,companyname,designation,salary,experience);
			 viewDAO.employeeDetails(newdel);
				RequestDispatcher dispatcher = request.getRequestDispatcher("employee-list.jsp");
	           dispatcher.forward(request, response);
			}
		}
		private void viewDetails(HttpServletRequest request,HttpServletResponse response) throws ServletException,
		IOException, SQLException, JSONException {
			int id=Integer.parseInt(request.getParameter("id"));
			System.out.println("id is:"+id);
			List<employee> listUser = viewDAO.viewDetails(id);
			request.setAttribute("listUser", listUser);
			List<details> listDetail=viewDAO.SelectDetails(id);
			request.setAttribute("listDetail", listDetail);
			
			ArrayList<Object> viewList = new ArrayList<>();
			for(int m=0;m<listUser.size();m++) {
				System.out.println(listUser.get(m).toString());
				JSONObject empObje = new JSONObject();
				empObje.put("phone", listUser.get(m).getPhone());
				empObje.put("mail", listUser.get(m).getMail());
				empObje.put("name", listUser.get(m).getName());
				empObje.put("id", listUser.get(m).getId());

				viewList.add(empObje);
			}
			for(int m=0;m<listDetail.size();m++) {
				System.out.println(listDetail.get(m).toString());
				JSONObject empObje = new JSONObject();
				empObje.put("fathername", listDetail.get(m).getFathername());
				empObje.put("mname", listDetail.get(m).getMname());
				empObje.put("status", listDetail.get(m).getStatus());
				empObje.put("address", listDetail.get(m).getAddress());
				empObje.put("degree", listDetail.get(m).getDegree());
				empObje.put("collegename", listDetail.get(m).getCollegename());
				empObje.put("percent", listDetail.get(m).getPercent());
				empObje.put("year", listDetail.get(m).getYear());
				empObje.put("address", listDetail.get(m).getAddress());
				empObje.put("companyname", listDetail.get(m).getCompanyname());
				empObje.put("designation", listDetail.get(m).getDesignation());
				empObje.put("salary", listDetail.get(m).getSalary());
				empObje.put("experience", listDetail.get(m).getExperience());

				viewList.add(empObje);
			}
            request.setCharacterEncoding("utf8");
			response.setContentType("application/json");
		    PrintWriter writer = response.getWriter();
            JSONObject object=new JSONObject();
            object.put("viewsList",viewList);
            System.out.println(object.toString());
		    response.setStatus(200);
		    writer.append(object.toString());
		    writer.close();
		
		
		    }
		private void search(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException, SQLException, JSONException
		{
			String search=request.getParameter("searches");
			PrintWriter pw=response.getWriter();
			System.out.println("searchId is:"+search);
			if(!userDAO.searchbysearchId(search).isEmpty()) {
				System.out.println("search by searchID is initiated");
			List<employee> listUsers = userDAO.searchbysearchId(search);
			System.out.println("obtained searches:"+listUsers);
			ArrayList<Object> searchList = new ArrayList<>();
			for(int m=0;m<listUsers.size();m++) {
				System.out.println(listUsers.get(m).toString());
				JSONObject empObje = new JSONObject();
				empObje.put("password", listUsers.get(m).getPassword());
				empObje.put("phone", listUsers.get(m).getPhone());
				empObje.put("mail", listUsers.get(m).getMail());
				empObje.put("name", listUsers.get(m).getName());
				empObje.put("id", listUsers.get(m).getId());

				searchList.add(empObje);
			}
            request.setCharacterEncoding("utf8");
			response.setContentType("application/json");
		    PrintWriter writer = response.getWriter();
            System.out.println("in servlet list is:"+listUsers.toString());
            JSONObject object=new JSONObject();
            object.put("sList",searchList);
            System.out.println(object.toString());
		    response.setStatus(200);
		    writer.append(object.toString());
		    writer.close();
			}
			else {
				pw.println("NO RESULTS FOUND");
			}
		}
		private void deleteSelected(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException, SQLException 
		{
			String[] checkid=request.getParameterValues("checkids");
			for(int l=0;l<checkid.length;l++) {
				System.out.println(checkid[l]);
			}
		System.out.println(userDAO.deleteSelected(checkid));
		viewDAO.deleteSelectedDetails(checkid);
		}
        private void logoutUser(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
	           HttpSession session=request.getSession(false);
	           session.invalidate();
	           RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
	           dispatcher.forward(request, response);
	            System.out.println("logout called");   
           }
		private void listUser(HttpServletRequest request, HttpServletResponse response)
				throws SQLException, IOException, ServletException, JSONException {
			 int page=1;
	            int recordsPerPage = 10;
	            System.out.println("this has to work");
	            if(request.getParameter("page") != null)
	            page = Integer.parseInt(request.getParameter("page"));
	            System.out.println("page value:"+page);
				List<employee> listUser = userDAO.selectAllUsers((page-1)*recordsPerPage, recordsPerPage);
				 int noOfRecords = userDAO.getNoOfRecords();
		            System.out.println("No Of Records:"+noOfRecords);
		            int noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);
		            System.out.println("no of pages:"+noOfPages);
					request.setAttribute("listUser", listUser);
		            request.setAttribute("noOfPages", noOfPages);
		            request.setAttribute("currentPage", page);
		            
				ArrayList<Object> emplList = new ArrayList<>();
				for(int m=0;m<listUser.size();m++) {
					System.out.println(listUser.get(m).toString());
					JSONObject empObje = new JSONObject();
					empObje.put("password", listUser.get(m).getPassword());
					empObje.put("phone", listUser.get(m).getPhone());
					empObje.put("mail", listUser.get(m).getMail());
					empObje.put("name", listUser.get(m).getName());
					empObje.put("id", listUser.get(m).getId());
					emplList.add(empObje);
				}
	              
	            request.setCharacterEncoding("utf8");
				response.setContentType("application/json");
			    PrintWriter writer = response.getWriter();
	            System.out.println("in servlet list is:"+listUser.toString());
	            
	            JSONObject object=new JSONObject();
	            object.put("currentpage", page);
	            object.put("empList",emplList);
	            object.put("noofpages",noOfPages);
	            JSONObject object1 =new JSONObject();
	            object1.put("currentpage", page);
	            object1.put("noofpages", noOfPages);
	            System.out.println(object1.toString());
	            System.out.println(object.toString());
	          
			    response.setStatus(200);
			    writer.append(object.toString());
			    writer.close();
			}
		
		private void validateOtp(HttpServletRequest request, HttpServletResponse response)
				throws SQLException, IOException, ServletException, JSONException {
			PrintWriter pw=response.getWriter();
			int otp=Integer.parseInt(request.getParameter("otp"));
			String mail=ck.getValue();
			System.out.println("cookie_mail:"+mail);
			System.out.println("frontend_otp:"+otp);
			int returnedotp=userDAO.validateOtp(mail);
			System.out.println("returned_otp:"+returnedotp);
			
		    JSONObject obj = new JSONObject();
			if(returnedotp==otp){
				System.out.println("redirected to list successfully");
				request.setCharacterEncoding("utf8");
				response.setContentType("application/json");
			    PrintWriter writer = response.getWriter();
			    obj.put("message","login_Successful"); 
			    response.setStatus(200);
			    writer.append(obj.toString());
			    writer.close();
			    				 
			   }
			 else {
				 request.setCharacterEncoding("utf8");
					response.setContentType("application/json");
				    PrintWriter writer = response.getWriter();
				    obj.put("message","login Failed"); 
				    response.setStatus(200);
				    writer.append(obj.toString());
				    writer.close();
				pw.println("<a href=login.jsp>OTP ENTERED WRONG!</a>");
			}	
		}
		
		private void loginUser(HttpServletRequest request, HttpServletResponse response)
				throws SQLException, IOException, ServletException, JSONException {
			PrintWriter pw=response.getWriter();
			String mail = request.getParameter("mail");
			String password = request.getParameter("password");
			JSONObject obj1=new JSONObject();

			if(userDAO.loginUser(mail, password)==true) {
				System.out.println("login Success");
			    userDAO.updateOtp(mail);
			    request.setCharacterEncoding("utf8");
			    response.setContentType("application/json");
		        obj1.put("message","Credentials matched enter OTP"); 
		        response.setStatus(200);
		        pw.append(obj1.toString());
		        pw.close();
			}
			else {
				request.setCharacterEncoding("utf8");
				response.setContentType("application/json");
			    obj1.put("message","Entered wrong Credentials"); 
			    response.setStatus(200);
			    pw.append(obj1.toString());
			    pw.close();
			    pw.println("<a href=login.jsp>ENTERED DETAILS WRONG TRY AGAIN!</a>");
			}
			ck=new Cookie("uname",mail);//creating cookie object  
		    response.addCookie(ck);//adding cookie in the response
		    System.out.println("cookie value is : "+ck.getValue());
		    HttpSession session=request.getSession();  
	        session.setAttribute("x",mail);
	     }

		private void showNewForm(HttpServletRequest request, HttpServletResponse response)
				throws ServletException, IOException {
				HttpSession session=request.getSession(false);
				String myName=(String)session.getAttribute("x");
				System.out.println("mail to show new form:"+myName);
		}
		private void showEditForm(HttpServletRequest request, HttpServletResponse response)
				throws SQLException, ServletException, IOException {
			HttpSession session=request.getSession(false);
			if(session.getAttribute("x")==null) {
				RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
				dispatcher.forward(request, response);
			}
			else {
			int id = Integer.parseInt(request.getParameter("id"));
			 HttpSession session1=request.getSession();  
		        session1.setAttribute("y",id);
			employee existingUser = userDAO.selectUser(id);
			RequestDispatcher dispatcher = request.getRequestDispatcher("employee-form.jsp");
			request.setAttribute("user", existingUser);
			dispatcher.forward(request, response);
		}}
		private void editdetailsform(HttpServletRequest request, HttpServletResponse response ) throws SQLException, ServletException, IOException {
			HttpSession session1=request.getSession(false);
			HttpSession session=request.getSession(false);
			if(session.getAttribute("x")==null) {
				RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
				dispatcher.forward(request, response);
			}
			else {
             int employeeId=(int)session1.getAttribute("y");
			System.out.println("servelt employeeId:"+employeeId);
			details existingUser=viewDAO.selectEmployee(employeeId);
		   	response.setHeader("Cache-Control","no-cache,no-store,must-revalidate"); 
			RequestDispatcher dispatcher = request.getRequestDispatcher("enterdetails.jsp");
			request.setAttribute("user", existingUser);
			dispatcher.forward(request, response);
			}
		}

		private void insertUser(HttpServletRequest request, HttpServletResponse response) 
				throws SQLException, IOException, ServletException {
			HttpSession session=request.getSession(false);
		
			if(session.getAttribute("x")==null) {
				RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
				dispatcher.forward(request, response);
			}
			else {
			String name = request.getParameter("name");
			String mail = request.getParameter("mail");
			String phone = request.getParameter("phone");
			String password = request.getParameter("password");
			employee newUser = new employee(name, mail,phone,password);
			userDAO.insertUser(newUser);
	        	RequestDispatcher dispatcher = request.getRequestDispatcher("enterdetails.jsp");
	          dispatcher.forward(request, response);
			}
		}

		private void updateUser(HttpServletRequest request, HttpServletResponse response) 
				throws SQLException, IOException, ServletException {
			HttpSession session=request.getSession(false);
			if(session.getAttribute("x")==null) {
				RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
				dispatcher.forward(request, response);
			}
			else {
			int id = Integer.parseInt(request.getParameter("id"));
			PrintWriter out=response.getWriter();
			out.println(request.getParameter("id"));
			String name = request.getParameter("name");
			String mail = request.getParameter("mail");
			String phone=request.getParameter("phone");
			String password =request.getParameter("password");

			employee book1 = new employee(id,name,mail,phone,password);
			userDAO.updateUser(book1);
        	response.setHeader("Cache-Control","no-cache,no-store,must-revalidate"); 
			response.sendRedirect("editdetails");		
		}}
private void updatedetails(HttpServletRequest request,HttpServletResponse response) throws SQLException, IOException, ServletException {
	 	     System.out.println("update details in servlet");
	 		HttpSession session1=request.getSession(false);
	 		HttpSession session=request.getSession(false);
	 			if(session.getAttribute("x")==null) {
	 				RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
	 				dispatcher.forward(request, response);
	           }
	          else {
              int employeeId=(int)session1.getAttribute("y");
         	  String fathername=request.getParameter("fathername");
	          String mname=request.getParameter("mname");
	          String status=request.getParameter("status");
	          String address=request.getParameter("address");
	          String degree=request.getParameter("degree");
	          String collegename=request.getParameter("collegename");
	          int year=Integer.parseInt(request.getParameter("year"));
	          String percent=request.getParameter("percent");
	          String companyname=request.getParameter("companyname");
	          String designation=request.getParameter("designation");
	          int salary=Integer.parseInt(request.getParameter("salary"));
	          int experience=Integer.parseInt(request.getParameter("experience"));
              details book2=new details(employeeId,fathername,mname,status,address,degree,collegename,year,percent,companyname,designation,salary,experience);
	          viewDAO.editdetails(book2);
   	          response.setHeader("Cache-Control","no-cache,no-store,must-revalidate"); 
		      RequestDispatcher dispatcher = request.getRequestDispatcher("employee-list.jsp");
		      dispatcher.forward(request, response);
	       }	   
        }
		private void deleteUser(HttpServletRequest request, HttpServletResponse response) 
				throws SQLException, IOException, ServletException {	
			int id = Integer.parseInt(request.getParameter("id"));
			int employeeId=id;
			userDAO.deleteUser(id);
			viewDAO.deletedetails(employeeId);
        	response.setHeader("Cache-Control","no-cache,no-store,must-revalidate"); 
		}
	}